# ofo-applet
ofo小程序
17届愣头青
啥? who am i?来我的[小主页](https://micelid.github.io)呗，或email我：sevenmicelid@gmail.com/2728324441@qq.com

## 下载源码提示
扫码功能是可以用的，我用的是我自己的微信号二维码，你们可以使自己的微信二维码，使用其他二维码可能报错哦。
